from flask import Flask, request, redirect
from flask.templating import render_template
from app import app, Profile, db

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def add_data():
    return render_template('add_profile.html')

'''
#Grabs data from the Form and adds it to the DB.
#data= First and Last name and Age
@app.route('/add' , methods=['POST'])
def profile():
    first_name = request.form.get("first_name")
    last_name = request.form.get("last_name")
    age = request.form.get("age")

    if first_name != "" and last_name != "" and age is not None:
        p = Profile(first_name=first_name, last_name=last_name, age=age)
        db.session.add(p)
        db.session.commit()
        return redirect('/')
    else: 
        return redirect('/')
'''