from flask_bootstrap import Bootstrap
from flask import Flask, request, redirect, session, url_for,flash
from flask.templating import render_template
from app import app, Profile, db
from datetime import date, datetime,timezone

from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, HiddenField
from wtforms.validators import DataRequired, length


bootstrap = Bootstrap(app)

class BlogForm(FlaskForm):
    name = StringField('What is your name?', validators=[DataRequired(),length(max=20)])
    blog = TextAreaField('What would you like to Post', validators=[DataRequired(),length(max=500)])
    submit = SubmitField('Submit')


@app.route('/', methods=['GET', 'POST'])
def index():
    form = BlogForm()
    
    try:
        PostUser = Profile.query.with_entities(Profile.user).all()
        print("User:")
        print(PostUser)

        UserBlog = Profile.query.with_entities(Profile.blogpost).all()
        print("Blog:")
        print(UserBlog)
        
        PostTime = Profile.query.with_entities(Profile.updated).all()
        print("Time Posted:")
        print(PostTime)
        print( 'THIS IS THE LENGTH OF LIST')
        
        num_of_users = len(PostUser)
        print(num_of_users)
    except Exception as e:
        #E holds description of error
        error_text = "<p>The error:<br>" + str(e) + "</p>"
        hed = '<h1> It do be broke.</h1>'
        return hed + error_text


    return render_template('index.html',form=form,name=session.get('name'),blog=session.get('blog'),PostUser = PostUser, UserBlog = UserBlog, PostTime = PostTime, Profile = Profile, num_of_users = num_of_users)


#This Page is used to create the webform and allow users to input data into it.
@app.route('/blogs',methods=['GET', 'POST'])
def blogpage():
    form = BlogForm()
    if form.validate_on_submit():
        users_name = session.get('name')
        users_blog = session.get('blog')
        if users_name is not None and users_name != session.get('name') and users_blog is not None:
            flash('You have changed your name')
        
        session['name'] = form.name.data
        session['blog'] = form.blog.data
        session['time'] = str(datetime.now(timezone.utc))
        form.name.data = ''
        form.blog.data = ''

        user = session.get('name')
        blog = session.get('blog')
        time = str(datetime.now(timezone.utc))
    #currentdate = datetime
    
        if user != '' and blog != '':
            p = Profile(user=user, blogpost=blog, updated=str(time))
            db.session.add(p)
            db.session.commit()

    return render_template('blogs.html',form=form,name=session.get('name'),blog=session.get('blog'),time=session.get('time'))

