from flask import Flask, request, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, migrate


app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = 'hard to guess string'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:temppassword@localhost/bloghw'



db = SQLAlchemy(app)

migrate = Migrate(app, db)

class Profile(db.Model):
	# Id : Field which stores unique id for every row in
	# database table.
	# User: Used to store the username of the user
	# blogpost: Used to store the blogpost
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(20), unique=False, nullable=False)
    blogpost = db.Column(db.String(500), unique=False, nullable=False)
    updated = db.Column(db.String(200), unique=False, nullable = False)
	# repr method represents how one object of this data table
	# will look like
    def __repr__(self):
	    return f"User : {self.user}, Blog: {self.blogpost}, Updated: {self.updated}"



if __name__ == '__main__':
    app.run()

#from flask import Moment
from app import routes